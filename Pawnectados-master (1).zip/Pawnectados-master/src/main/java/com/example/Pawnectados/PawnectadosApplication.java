package com.example.Pawnectados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  PawnectadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PawnectadosApplication.class, args);
	}

}
