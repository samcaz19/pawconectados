package com.example.Pawnectados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawnectadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
